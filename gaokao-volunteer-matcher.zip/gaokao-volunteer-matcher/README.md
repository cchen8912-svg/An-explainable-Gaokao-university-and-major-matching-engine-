# 高考志愿匹配与就业路径分析系统

一个面向中国高考志愿研究的 Python 开源示例项目，将**录取匹配、专业匹配、就业薪资、硕士/博士学历提醒和教育投资回报（ROI）**放在同一套可解释框架中。

> **重要说明**：仓库中的录取与薪资数据均为演示数据，不代表任何真实学校、专业或年份的官方数据。正式使用时，应替换为合法取得、来源明确且经过清洗验证的数据。

## 核心功能

- 高考省份、年份、分数/位次、选科约束
- 历史录取位次匹配
- 专业偏好与避选专业
- 城市偏好
- 冲 / 稳 / 保 / 高风险分类
- 专业本科就业率示例指标
- 薪资 P25 / P50 / P75 区间预测
- 硕士/博士学历要求提醒
- 本科 vs 硕士教育投资回收期示例计算
- 可解释推荐原因
- pytest 自动测试

## 项目结构

```text
gaokao-volunteer-matcher/
├── main.py
├── README.md
├── requirements.txt
├── LICENSE
├── data/
│   ├── admission_history.csv
│   └── career_profiles.csv
├── src/
│   ├── models.py
│   ├── data_loader.py
│   ├── scoring.py
│   ├── career.py
│   └── matcher.py
└── tests/
    ├── test_scoring.py
    ├── test_career.py
    └── test_matcher.py
```

## 快速开始

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py
pytest -q
```

Windows：

```powershell
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
pytest -q
```

## 匹配逻辑

总匹配度默认由五个维度组成：

| 维度 | 默认权重 |
|---|---:|
| 历史位次匹配 | 40% |
| 专业偏好 | 20% |
| 院校层次 | 10% |
| 城市偏好 | 10% |
| 就业路径 | 20% |

这些权重只是示例，不代表统计学上已经验证的最优权重。生产版本应使用历史回测和交叉验证进行校准。

## 薪资预测

当前版本使用 P25/P50/P75 的演示数据，并根据学历和工作年限做简单调整。生产版本建议改成分地区、分行业、分岗位的数据模型，并报告预测区间、样本量、数据年份和置信度。

## 硕博提醒

系统不把“硕士更常见”解释为“本科无法就业”。输出应理解为：不同岗位、地区、单位性质和年份下，学历可能改变岗位选择范围或竞争条件。

## ROI

示例模型把以下因素纳入计算：

- 研究生学习年限
- 学费
- 生活成本
- 读研期间放弃本科就业的机会成本
- 本科与硕士月薪 P50 差值

ROI 仅表示一个简化的回收期指标，不等同于真实投资收益率。

## 数据治理建议

正式部署时建议给每条数据增加：

```text
source
source_url
publication_date
data_year
province
sample_size
last_updated
methodology
```

并对录取数据进行年份、招生计划、专业组、选科要求和政策变化校验。

## Roadmap

- [ ] 接入真实省份历年录取位次数据
- [ ] 新高考专业组/院校专业组模型
- [ ] 招生计划变化修正
- [ ] 位次而非裸分的跨年映射
- [ ] 行业/岗位级就业数据
- [ ] 城市薪资修正
- [ ] 本科/硕士/博士生命周期现金流模型
- [ ] Monte Carlo 风险模拟
- [ ] Web API
- [ ] Streamlit/React 前端
- [ ] 数据版本管理与自动质量检查

## License

MIT
