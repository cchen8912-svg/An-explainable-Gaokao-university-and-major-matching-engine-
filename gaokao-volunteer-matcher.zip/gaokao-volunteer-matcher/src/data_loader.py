import csv
from pathlib import Path
from .models import AdmissionRecord, CareerProfile

def _split(value: str):
    return [x.strip() for x in value.split("|") if x.strip()]

def load_admissions(path: str | Path):
    rows = []
    with open(path, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            rows.append(AdmissionRecord(
                university=r["university"], major=r["major"], province=r["province"],
                year=int(r["year"]), min_rank=int(r["min_rank"]),
                required_subjects=_split(r.get("required_subjects", "")),
                city=r.get("city", ""), university_tier=r.get("university_tier", "普通本科"),
                annual_tuition=float(r.get("annual_tuition", 0) or 0)
            ))
    return rows

def load_careers(path: str | Path):
    rows = []
    with open(path, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            rows.append(CareerProfile(
                major=r["major"], employment_rate_bachelor=float(r["employment_rate_bachelor"]),
                salary_p25=float(r["salary_p25"]), salary_p50=float(r["salary_p50"]),
                salary_p75=float(r["salary_p75"]), master_salary_p50=float(r["master_salary_p50"]),
                phd_salary_p50=float(r["phd_salary_p50"]), master_requirement=r["master_requirement"],
                phd_requirement=r["phd_requirement"], demand_score=float(r["demand_score"]),
                competition_score=float(r["competition_score"]), master_years=int(r.get("master_years", 3)),
                phd_years=int(r.get("phd_years", 4)), annual_tuition_master=float(r.get("annual_tuition_master", 0) or 0),
                annual_tuition_phd=float(r.get("annual_tuition_phd", 0) or 0), explanation=r.get("explanation", "")
            ))
    return rows
