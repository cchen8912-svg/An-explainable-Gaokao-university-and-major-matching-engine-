from src.scoring import classify_risk, rank_score, weighted_score

def test_rank_score_is_bounded():
    assert 0 <= rank_score(8500, 9000) <= 100

def test_risk_labels():
    assert classify_risk(8500, 9000) in {"保", "稳", "冲", "高风险"}

def test_weighted_score():
    assert weighted_score({"rank":100,"major":100,"university":100,"city":100,"career":100}) == 100
