from typing import Iterable, List
from .models import Applicant, AdmissionRecord, CareerProfile, MatchResult
from .scoring import DEFAULT_WEIGHTS, classify_risk, rank_score, weighted_score
from .career import degree_alert, education_roi_years, predict_salary

class VolunteerMatcher:
    def __init__(self, admissions: Iterable[AdmissionRecord], careers: Iterable[CareerProfile]):
        self.admissions = list(admissions)
        self.careers = {c.major: c for c in careers}

    def match(self, applicant: Applicant, limit: int = 20) -> List[MatchResult]:
        results = []
        for record in self.admissions:
            if record.province != applicant.province or record.year != applicant.year:
                continue
            if record.required_subjects and not set(record.required_subjects).issubset(set(applicant.subjects)):
                continue
            if record.major in applicant.avoided_majors:
                continue

            career = self.careers.get(record.major)
            if not career:
                continue

            rscore = rank_score(applicant.rank, record.min_rank)
            risk = classify_risk(applicant.rank, record.min_rank)
            mscore = 100.0 if record.major in applicant.preferred_majors else 55.0
            uscore = {"985": 100, "211": 90, "双一流": 85, "普通本科": 65}.get(record.university_tier, 60)
            cscore = 100.0 if record.city in applicant.preferred_cities else 60.0
            cscore2 = (career.employment_rate_bachelor * 0.6 + career.demand_score * 0.4) * 100
            total = weighted_score({"rank": rscore, "major": mscore, "university": uscore, "city": cscore, "career": cscore2})

            salary = predict_salary(career, "本科")["p50"]
            roi = education_roi_years(
                salary,
                career.master_salary_p50,
                career.master_years,
                career.annual_tuition_master * career.master_years,
                30000 * career.master_years,
            )
            reasons = []
            if record.major in applicant.preferred_majors:
                reasons.append("符合专业偏好")
            if record.city in applicant.preferred_cities:
                reasons.append("符合城市偏好")
            if risk in ("稳", "保"):
                reasons.append("历史位次匹配相对稳定")
            elif risk == "冲":
                reasons.append("历史位次存在一定冲刺空间")
            if career.master_requirement in ("硕士较常见", "硕士明显更有利"):
                reasons.append("系统提示：硕士学历可能明显影响部分岗位选择")
            if career.phd_requirement == "博士较常见":
                reasons.append("系统提示：科研/高校等部分岗位博士较常见")

            results.append(MatchResult(
                record.university, record.major, risk, total, risk, rscore, mscore,
                uscore, cscore, cscore2, salary, degree_alert(career), roi, reasons
            ))
        return sorted(results, key=lambda x: x.match_score, reverse=True)[:limit]
