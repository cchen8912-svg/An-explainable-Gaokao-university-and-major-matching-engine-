from src.career import education_roi_years, predict_salary
from src.models import CareerProfile

def profile():
    return CareerProfile("测试专业", .9, 6000, 8000, 12000, 10000, 14000, "硕士较常见", "博士较常见", .9, .7)

def test_salary_prediction():
    result = predict_salary(profile(), "本科")
    assert result["p50"] == 8000

def test_roi():
    roi = education_roi_years(8000, 10000, 3, 30000, 60000)
    assert roi is not None and roi > 0
