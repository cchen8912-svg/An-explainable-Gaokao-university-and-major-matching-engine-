from pathlib import Path
from src.data_loader import load_admissions, load_careers
from src.matcher import VolunteerMatcher
from src.models import Applicant

ROOT = Path(__file__).parents[1]

def test_matcher_returns_results():
    matcher = VolunteerMatcher(
        load_admissions(ROOT / "data/admission_history.csv"),
        load_careers(ROOT / "data/career_profiles.csv"),
    )
    applicant = Applicant("安徽", 2026, 620, 8500, ["物理", "化学"], ["计算机科学与技术"], ["南京"], ["金融学"])
    results = matcher.match(applicant)
    assert results
    assert all(r.major != "金融学" for r in results)
