from typing import Optional
from .models import CareerProfile

def degree_alert(profile: CareerProfile) -> str:
    return (
        f"硕士：{profile.master_requirement}；"
        f"博士：{profile.phd_requirement}。"
        "学历要求会因岗位、地区、单位性质和年份变化，不应视为绝对门槛。"
    )

def predict_salary(profile: CareerProfile, degree: str = "本科", experience_years: int = 0) -> dict:
    base = {
        "本科": (profile.salary_p25, profile.salary_p50, profile.salary_p75),
        "硕士": (profile.salary_p25 * 1.12, profile.master_salary_p50, profile.salary_p75 * 1.18),
        "博士": (profile.salary_p25 * 1.20, profile.phd_salary_p50, profile.salary_p75 * 1.35),
    }.get(degree)
    if base is None:
        raise ValueError("degree must be 本科、硕士或博士")
    multiplier = 1.0 + min(max(experience_years, 0), 10) * 0.05
    return {
        "p25": round(base[0] * multiplier, 2),
        "p50": round(base[1] * multiplier, 2),
        "p75": round(base[2] * multiplier, 2),
        "currency": "CNY/month",
        "note": "示例模型输出；正式部署应使用经验证的、按年份/地区/岗位分层的公开数据。",
    }

def education_roi_years(
    bachelor_salary: float,
    graduate_salary: float,
    graduate_years: int,
    tuition_total: float,
    living_cost_total: float,
) -> Optional[float]:
    if graduate_salary <= bachelor_salary:
        return None
    opportunity_cost = bachelor_salary * graduate_years + tuition_total + living_cost_total
    annual_gain = (graduate_salary - bachelor_salary) * 12
    return round(opportunity_cost / annual_gain, 2) if annual_gain > 0 else None
