from dataclasses import dataclass, field
from typing import Dict, List, Optional

@dataclass
class Applicant:
    province: str
    year: int
    score: int
    rank: int
    subjects: List[str]
    preferred_majors: List[str] = field(default_factory=list)
    preferred_cities: List[str] = field(default_factory=list)
    avoided_majors: List[str] = field(default_factory=list)
    degree_goal: str = "本科"

@dataclass
class AdmissionRecord:
    university: str
    major: str
    province: str
    year: int
    min_rank: int
    max_rank: Optional[int] = None
    required_subjects: List[str] = field(default_factory=list)
    city: str = ""
    university_tier: str = "普通本科"
    annual_tuition: float = 0.0

@dataclass
class CareerProfile:
    major: str
    employment_rate_bachelor: float
    salary_p25: float
    salary_p50: float
    salary_p75: float
    master_salary_p50: float
    phd_salary_p50: float
    master_requirement: str
    phd_requirement: str
    demand_score: float
    competition_score: float
    bachelor_years: int = 4
    master_years: int = 3
    phd_years: int = 4
    annual_tuition_master: float = 0.0
    annual_tuition_phd: float = 0.0
    explanation: str = ""

@dataclass
class MatchResult:
    university: str
    major: str
    category: str
    match_score: float
    admission_risk: str
    rank_score: float
    major_score: float
    university_score: float
    city_score: float
    career_score: float
    salary_p50: float
    degree_alert: str
    roi_years: Optional[float]
    reasons: List[str] = field(default_factory=list)
