from typing import Dict

DEFAULT_WEIGHTS: Dict[str, float] = {
    "rank": 0.40,
    "major": 0.20,
    "university": 0.10,
    "city": 0.10,
    "career": 0.20,
}

def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))

def rank_score(candidate_rank: int, historical_min_rank: int) -> float:
    if candidate_rank <= 0 or historical_min_rank <= 0:
        return 0.0
    # Smaller rank is stronger. 100 means comfortably inside historical range.
    ratio = historical_min_rank / candidate_rank
    if ratio >= 1.20:
        return 100.0
    if ratio >= 1.00:
        return 75.0 + (ratio - 1.00) * 125.0
    if ratio >= 0.85:
        return 45.0 + (ratio - 0.85) * 200.0
    return clamp(45.0 * ratio / 0.85)

def classify_risk(candidate_rank: int, historical_min_rank: int) -> str:
    ratio = historical_min_rank / candidate_rank
    if ratio >= 1.05:
        return "保"
    if ratio >= 0.92:
        return "稳"
    if ratio >= 0.78:
        return "冲"
    return "高风险"

def weighted_score(parts: Dict[str, float], weights: Dict[str, float] = DEFAULT_WEIGHTS) -> float:
    return round(sum(parts[k] * weights[k] for k in weights), 2)
