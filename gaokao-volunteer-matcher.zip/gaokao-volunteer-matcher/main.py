from pathlib import Path
from src.data_loader import load_admissions, load_careers
from src.models import Applicant
from src.matcher import VolunteerMatcher

ROOT = Path(__file__).parent


def main():
    applicant = Applicant(
        province="安徽", year=2026, score=620, rank=8500,
        subjects=["物理", "化学"],
        preferred_majors=["计算机科学与技术", "电子信息工程"],
        preferred_cities=["南京", "杭州"],
        avoided_majors=["金融学"],
    )
    matcher = VolunteerMatcher(
        load_admissions(ROOT / "data/admission_history.csv"),
        load_careers(ROOT / "data/career_profiles.csv"),
    )
    results = matcher.match(applicant)
    print("=== 高考志愿匹配示例 ===")
    for i, r in enumerate(results, 1):
        print(f"\n{i}. {r.university} / {r.major}")
        print(f"匹配度: {r.match_score} | 风险: {r.admission_risk}")
        print(f"本科月薪P50(示例): ¥{r.salary_p50:,.0f}")
        print(f"学历提醒: {r.degree_alert}")
        print(f"硕士ROI回收期(示例): {r.roi_years} 年")
        print("原因:", "；".join(r.reasons))

if __name__ == "__main__":
    main()
